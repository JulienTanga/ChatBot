﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json.Linq;

namespace LivePersonAgentBot.Bots
{
    public class LivePersonAgentBot : ActivityHandler
    {
        private readonly BotState _conversationState;

        public LivePersonAgentBot(ConversationState conversationState)
        {
            _conversationState = conversationState;
        }
        static Dictionary<string, string> Politesse = new Dictionary<string, string>
        {
            ["Bonjour"] = ",comment pourrais-je vous aider?",
            ["Hello"] = ", How may I help you?",
            ["Pays"] = "Dites moi le pays je donnes la capitale",
            ["Incident"] = "Quel type d'incident?",
            ["Contacter"] = "Quel type d'incident?",

        };

        static Dictionary<string, string> Menaces = new Dictionary<string, string>
        {
            ["Attentat"] = "J'appelle la brigade anti terrorisme",
            ["Bombe"] = "J'appelle les demineurs",
            ["Meurtre"] = "J'appele la police!",
            ["Vol"] = "Je vais trouver le voleur",
            ["Insultes"] = "Mais voyons parlez mieux",
           
        };


        static Dictionary<string, string> Capitals = new Dictionary<string, string>
        {
            ["France"] = "Paris",
            ["Cameroun"] = "Yaounde",
            ["UAE"] = "Abu Dhabi",
            ["Italie"] = "Rome",
            ["Japon"] = "Tokyo",
            ["Pologne"] = "Varsovie",
            ["Allemagne"] = "peut-etre Hamburg ?"
        };

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var conversationStateAccessors = _conversationState.CreateProperty<LoggingConversationData>(nameof(LoggingConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new LoggingConversationData());

            var userText = turnContext.Activity.Text.ToLowerInvariant();
            if (userText.Contains("Questions"))
            {
                await turnContext.SendActivityAsync("Je vous redirige vers un quelqu'un de quallifié");

                var transcript = new Transcript(conversationData.ConversationLog.Where(a => a.Type == ActivityTypes.Message).ToList());

                var evnt = EventFactory.CreateHandoffInitiation(turnContext,
                    new { Skill = "credit-cards" },
                    transcript);

                await turnContext.SendActivityAsync(evnt);
            }
            else
            {

                string replyText = $"Je ne peux pas vous aider!";

                if (userText == "Excusez-moi")
                {
                    replyText = $"Comment pourrais-je vous aider?";
                }
                else
                {
                    foreach (var country in Politesse.Keys)
                    {
                        if (userText.Contains(country.ToLower()))
                        {
                            replyText = $"Oh {country}, {Politesse[country]}";
                        }
                    }
                    foreach (var country in Capitals.Keys)
                    {
                        if (userText.Contains(country.ToLower()))
                        {
                            replyText = $"Alors la capitale de {country} est {Capitals[country]}";
                        }
                    }
                    foreach (var country in Menaces.Keys)
                    {
                        if (userText.Contains(country.ToLower()))
                        {
                            replyText = $"Alors s'il s'agit de {country}, {Menaces[country]}";
                        }
                    }
                }

                await turnContext.SendActivityAsync(MessageFactory.Text(replyText, replyText), cancellationToken);
            }
            
        }

        protected override async Task OnEventAsync(ITurnContext<IEventActivity> turnContext, CancellationToken cancellationToken)
        {
            if(turnContext.Activity.Name == HandoffEventNames.HandoffStatus)
            {
                var conversationStateAccessors = _conversationState.CreateProperty<LoggingConversationData>(nameof(LoggingConversationData));
                var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new LoggingConversationData());

                Activity replyActivity;
                var state = (turnContext.Activity.Value as JObject)?.Value<string>("state");
                if (state == HandoffStates.Typing)
                {
                    replyActivity = new Activity
                    {
                        Type = ActivityTypes.Typing,
                        Text = "agent is typing",
                    };
                }
                else if (state == HandoffStates.Accepted)
                {
                    replyActivity = MessageFactory.Text("An agent has accepted the conversation and will respond shortly.");
                    await _conversationState.SaveChangesAsync(turnContext);
                }
                else if (state == HandoffStates.Completed)
                {
                    replyActivity = MessageFactory.Text("The agent has closed the conversation.");
                }
                else
                {
                    replyActivity = MessageFactory.Text($"Conversation status changed to '{state}'");
                }

                await turnContext.SendActivityAsync(replyActivity);
            }

            await base.OnEventAsync(turnContext, cancellationToken);
        }
    }
}
